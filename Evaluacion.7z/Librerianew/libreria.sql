-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 20-06-2022 a las 06:13:33
-- Versión del servidor: 10.4.24-MariaDB
-- Versión de PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `libreria`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `books`
--

CREATE TABLE `books` (
  `id_books` int(10) NOT NULL,
  `id_cat` int(10) NOT NULL,
  `id_user` int(10) NOT NULL,
  `name_book` varchar(50) NOT NULL,
  `autor_book` varchar(50) DEFAULT NULL,
  `edit_book` varchar(50) DEFAULT NULL,
  `stock_book` int(10) NOT NULL,
  `vendidos_book` int(10) DEFAULT NULL,
  `file_book` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `books`
--

INSERT INTO `books` (`id_books`, `id_cat`, `id_user`, `name_book`, `autor_book`, `edit_book`, `stock_book`, `vendidos_book`, `file_book`) VALUES
(68, 12, 1, 'El Economista Callejero', 'Axel Kaiser', 'Ediciones El Mercurio', 23, NULL, '../img/upload/Eco.webp'),
(69, 9, 1, 'Romper El Circulo', 'Collen  Hoover', 'Planeta', 22, NULL, '../img/upload/romper.webp'),
(70, 14, 1, 'Heartstopper #2', 'Alice Oseman', 'Zig Zag', 22, NULL, '../img/upload/heart2.webp'),
(71, 14, 1, 'Heartstopper #1', 'Alice Oseman', 'Vergara Y Riba', 45, NULL, '../img/upload/heart1.webp'),
(72, 14, 1, 'Heartstopper #3', 'Alice Oseman', 'Vergara Y Riba', 2, NULL, '../img/upload/heart3.webp'),
(73, 14, 1, 'Heartstopper #4', 'Alice Oseman', 'Vergara Y Riba', 21, NULL, '../img/upload/heart4.webp'),
(75, 15, 1, 'Violeta', 'Isabel Allende', 'Sudamericana', 23, NULL, '../img/upload/violeta.webp'),
(76, 9, 1, 'Los Siete Maridos De Evelyn Hugo', 'Taylor Jenkins Reid', 'Umbriel Editores', 1, NULL, '../img/upload/lossiete.webp'),
(77, 16, 1, 'Las Costureras De Auschwitz', 'Lucy Adligton', 'Planeta', 6, NULL, '../img/upload/lascost.webp'),
(78, 17, 1, 'El Caso Alaska Sanders', 'Joel Dicker', 'Alfaguara', 22, NULL, '../img/upload/alaska.webp'),
(79, 18, 1, 'Creer O No Creer', 'Joseph R. Ramos', 'Paidos', 22, NULL, '../img/upload/creer.webp'),
(80, 12, 1, 'Padre Rico Padre Pobre (20 Años)', 'Robert T. Kiyosaki', 'Aguilar', 7, NULL, '../img/upload/padre.webp'),
(81, 20, 1, 'Hooky', 'Miriam Bonastre Tru', 'Martinez De Roca', 5, NULL, '../img/upload/hooky.webp'),
(82, 18, 1, 'Piñera Offshore', 'Sergio Jara', 'Planeta', 234, NULL, '../img/upload/pi;era.webp'),
(83, 9, 1, 'El Mapa De Los Anhelos', 'Alice Kellen', 'El Mapa De Los Anhelos', 21, NULL, '../img/upload/elmapa.webp'),
(84, 14, 1, 'El Principito (Td)', 'Antoine De Saintexupery', 'Origo Ediciones', 5, NULL, '../img/upload/principe.webp'),
(85, 21, 1, 'El Sueño De Sooley', 'John Grisham', 'El Sueño De Sooley', 22, NULL, '../img/upload/elsue;o.webp'),
(86, 16, 1, 'Todo Legal', 'Carlos Tromben', 'Planeta', 12, NULL, '../img/upload/legal.webp');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id_cat` int(10) NOT NULL,
  `name_cat` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id_cat`, `name_cat`) VALUES
(2, 'Terror'),
(3, 'Accion'),
(4, 'Comedia'),
(5, 'Autobiografico'),
(6, 'Suspenso'),
(7, 'Salud'),
(8, 'Thriller'),
(9, 'Romance'),
(10, 'Drama'),
(11, 'Fantasia'),
(12, 'Economia'),
(14, 'Literatura Juvenil'),
(15, 'Literatura Latinoamericana'),
(16, 'Historia'),
(17, 'Policial'),
(18, 'Sociologia'),
(19, 'Comics'),
(20, 'Manga'),
(21, 'Autoayuda');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id_user` int(10) NOT NULL,
  `name_user` varchar(15) NOT NULL,
  `email_user` varchar(30) NOT NULL,
  `pass_user` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id_user`, `name_user`, `email_user`, `pass_user`) VALUES
(1, 'Juanito', 'juanito@gmail.com', 'juanito123');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id_books`),
  ADD KEY `id_cat` (`id_cat`),
  ADD KEY `id_user` (`id_user`);

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id_cat`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `books`
--
ALTER TABLE `books`
  MODIFY `id_books` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id_cat` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `books`
--
ALTER TABLE `books`
  ADD CONSTRAINT `books_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`) ON UPDATE CASCADE,
  ADD CONSTRAINT `books_ibfk_2` FOREIGN KEY (`id_cat`) REFERENCES `categorias` (`id_cat`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
