<?php 
require '../cnx.php';
//Verificamos si fue enviado id-vendido
$idVendido = $_POST['id-vendido'] ? $_POST['id-vendido']: $_GET['id-vendido'];

$sqlSelect = "SELECT * FROM books WHERE id_books = $idVendido;";
$psSelect = $cnx->prepare($sqlSelect);
$psSelect->execute(); 
$resLibro = $psSelect->fetchAll();

//Recorremos los datos de la tabla según el id previamente recibido
foreach ($resLibro as $libro){
    header("location: ../home/index.php");
//Si existe el idVendido actualizaremos el campo de vendidos_book
if ($idVendido) {
    //Si hay stock del libro procederá a sumarse 1 al contador del campo de vendidos_book y restarse 1 al stock_book
    if($libro['stock_book']){
        $sqlUpdate = "UPDATE `books` SET `vendidos_book` = ? WHERE `id_books` = ?;";
        $psUpdate = $cnx->prepare($sqlUpdate);
        $psUpdate->execute(array($libro['vendidos_book']+1, $idVendido));

        $sqlUpdateStock = "UPDATE `books` SET `stock_book` = ? WHERE `id_books` = ?;";
        $psUpdateStock = $cnx->prepare($sqlUpdateStock);
        $psUpdateStock->execute(array($libro['stock_book']-1, $idVendido));
    }
    if ($psUpdate->rowCount()) {
        echo "modificacion correcta";
        header("location: ../home/index.php");
    } else {
        echo "modificacion incorrecta";
    }
    
} 
}
