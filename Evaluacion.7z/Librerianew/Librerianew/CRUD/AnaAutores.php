<?php
error_reporting(0);
require '../cnx.php';
$ruta = '../';
//Si se presiona el botón de enviar datos, instanciamos las variables necesarias para agregar un libro nuevo
if ($_POST['enviado']) {
    $name_autor = $_POST['name_autor'];
    $msgGeneral = "";
    $validacion = True;

    //validamos si los campos obligatorios están vacíos

    if (!$name_autor) {
        $validacion = False;
    }
    //Si todo está correcto insertamos el nuevo libro en la base de datos
    if ($validacion) {
        $sqlSelectAut = "SELECT * FROM `autores` WHERE name_autor = '$name_autor';";
        $psAut = $cnx->prepare($sqlSelectAut);
        $psAut->execute();
        $resAut = $psAut->fetchAll();

        if(!$resAut){
            $sqlInsert = "INSERT INTO `autores`(`name_autor`) VALUES (?);";
            $psInsert = $cnx->prepare($sqlInsert);
            $psInsert->execute(array($name_autor));
            if ($psInsert->rowCount()) {
                $msgGeneral = 'Se agrego correctamente';
            }
        }else{
            $msgGeneral = 'Este autor ya existe';
        }

        
    } else {
        $msgGeneral = 'Todos los campos son necesarios';
        // echo $msgGeneral;
    }
}
include("../inc/header.php");
?>
<!--Body Center, Aqui va el contenido-->
<div id="body-content" style="color: black;">
    <div id="body-center">
        <div id="body-header-static" style=" margin-left: 5rem; margin-top: 2rem; margin-bottom: 3rem;">
            <p>Añadir Autor</p>
        </div>
        <form action="AnaAutores.php" method="POST" enctype="multipart/form-data" id="form-aña">
            <div id="vista-previa-container" style="display: inline-flex; height: 30rem">
                <div id="input-añadir-libro">
                    <p>Nombre</p>
                    <input type="text" name="name_autor" id="name_autor" minlength="4" maxlength="30">
                    <input type="hidden" name="enviado" id="enviado" value="1">
                    <div id="btns-under-input-aña" style="margin-top: 0rem;">
                        <a href="../home/index.php" style="color: #686767;"><button type="button" id="cancelar" style="border: #7c7c7c solid 2px; margin-right: 2rem; cursor:pointer;">CANCELAR</button></a>
                        <button id="aplicar">APLICAR</button>
                        <p style="margin-top:1rem;"><?php echo $msgGeneral; ?></p>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<!--Body Center end-->

<?php include("../inc/footer.php"); ?>
<style>
    .inputfile {
        width: 0.1px;
        height: 0.1px;
        opacity: 0;
        overflow: hidden;
        position: absolute;
z-index: -1;}
</style>

<script>

//Muestra una barra debajo de "inicio" (barra de navegacion)

    window.onload = function() {
        let productos = document.getElementById('Productos-navbar');
        let dash = document.getElementById('Dashboard-navbar');
        let categorias = document.getElementById('Categorias-navbar');
        let autores = document.getElementById('Auto-navbar');
        autores.style.borderBottom = '#ff2163 solid 3px';
        autores.style.fontWeight = 'bold';
        autores.style.color = 'black';
        productos.style.color = '#a9a6a6';

        
    }
</script>