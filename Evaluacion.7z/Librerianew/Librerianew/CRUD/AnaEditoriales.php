<?php
error_reporting(0);
require '../cnx.php';
$ruta = '../';
//Si se presiona el botón de enviar datos, instanciamos las variables necesarias para agregar un libro nuevo
if ($_POST['enviado']) {
    $name_edit = $_POST['name_edit'];
    $msgGeneral = "";
    $validacion = True;

    //validamos si los campos obligatorios están vacíos

    if (!$name_edit) {
        $validacion = False;
    }
    //Si todo está correcto insertamos el nuevo libro en la base de datos
    if ($validacion) {
        $sqlSelectEdit = "SELECT * FROM `editoriales` WHERE name_edit = '$name_edit';";
        $psEdit = $cnx->prepare($sqlSelectEdit);
        $psEdit->execute();
        $resEditorial = $psEdit->fetchAll();

        if(!$resEditorial){
            $sqlInsert = "INSERT INTO `editoriales`(`name_edit`) VALUES (?);";
            $psInsert = $cnx->prepare($sqlInsert);
            $psInsert->execute(array($name_edit));
            if ($psInsert->rowCount()) {
                $msgGeneral = 'Se agrego correctamente';
            }
        }else{
            $msgGeneral = 'Esta editorial ya existe';
        }

        
    } else {
        $msgGeneral = 'Todos los campos son necesarios';
        // echo $msgGeneral;
    }
}
include("../inc/header.php");
?>
<!--Body Center, Aqui va el contenido-->
<div id="body-content" style="color: black;">
    <div id="body-center">
        <div id="body-header-static" style=" margin-left: 5rem; margin-top: 2rem; margin-bottom: 3rem;">
            <p>Añadir Editorial</p>
        </div>
        <form action="AnaEditoriales.php" method="POST" enctype="multipart/form-data" id="form-aña">
            <div id="vista-previa-container" style="display: inline-flex; height: 30rem">
                <div id="input-añadir-libro">
                    <p>Nombre</p>
                    <input type="text" name="name_edit" id="name_edit" minlength="4" maxlength="30">
                    <input type="hidden" name="enviado" id="enviado" value="1">
                    <div id="btns-under-input-aña" style="margin-top: 0rem;">
                        <a href="../home/index.php" style="color: #686767;"><button type="button" id="cancelar" style="border: #7c7c7c solid 2px; margin-right: 2rem; cursor:pointer;">CANCELAR</button></a>
                        <button id="aplicar">APLICAR</button>
                        <p style="margin-top:1rem;"><?php echo $msgGeneral; ?></p>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<!--Body Center end-->

<?php include("../inc/footer.php"); ?>
<style>
    .inputfile {
        width: 0.1px;
        height: 0.1px;
        opacity: 0;
        overflow: hidden;
        position: absolute;
        z-index: -1;
    }
</style>

<script>

//Muestra una barra debajo de "inicio" (barra de navegacion)

    window.onload = function() {
        let productos = document.getElementById('Productos-navbar');
        let dash = document.getElementById('Dashboard-navbar');
        let categorias = document.getElementById('Categorias-navbar');
        let autores = document.getElementById('Auto-navbar');
        dash.style.borderBottom = '#ff2163 solid 3px';
        dash.style.fontWeight = 'bold';
        dash.style.color = 'black';
        productos.style.color = '#a9a6a6';

        
    }
</script>