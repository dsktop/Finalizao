<?php
error_reporting(0);
$msg = "";
$validacion = True;
require 'cnx.php';
   
   session_start();

   //Instanciamos las variables de session

   $email_user = $_POST['email_user'];
   $pass_user = $_POST['pass_user'];

   $sql = "SELECT * FROM users WHERE email_user = '$email_user' AND pass_user = '$pass_user';";
   $resultado = $cnx->query($sql);
   $rsUsuarios = $resultado->fetch(PDO::FETCH_ASSOC);

   //Validamos si los campos están vacíos y si usuario y contraseña son correctos
   if($email_user === '' && $pass_user === '') {
      $_SESSION['msgError'] = 'Todos los campos son Obligatorios.';
      //Si están vacíos nos redirige de nuevo a login.php
      header("location: login.php");
   }else if($rsUsuarios['email_user'] == $email_user && $rsUsuarios['pass_user'] == $pass_user) {
         $_SESSION['email_user'] = $email_user;
         //Si todo está correcto nos redirige a nuestro index
         header("location: home/index.php");
   }else {
      //Si están incorrectos nos redirige de nuevo a login.php
         $_SESSION['msgError'] = 'Error! EMAIL O PASSWORD INCORRECTOS.';
         header("location: login.php");
   }
?>