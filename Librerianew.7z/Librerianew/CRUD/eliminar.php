<?php 
require '../cnx.php';
//Revisamos si id-eliminado a sido enviado
$idEliminado = $_POST['id-eliminado'] ? $_POST['id-eliminado']: $_GET['id-eliminado'];
//Si existe el id-eliminado borramos los datos que correspondan
if ($idEliminado) {
    
    $sqlDelete = "DELETE FROM `books` WHERE `id_books` = ?;";
    $psDelete = $cnx->prepare($sqlDelete);
    $psDelete->execute(array($idEliminado));
    if($psDelete->rowCount()){
        //Luego de eliminar nos redirigimos al index
        header("Location:../home/index.php");
    }
}
?>