<?php
error_reporting(0);
require '../cnx.php';
$ruta = '../';
//Revisamos si codBook ha sido envíado y si el boton a sido presionado modificamos los datos según corresponda al ID
$codBook = $_POST['codBook'] ? $_POST['codBook'] : $_GET['codBook'];
if ($_POST['enviado']) {
    $name_book = $_POST['name_book'];
    $autor_book = $_POST['autor_book'];
    $categoria_book = $_POST['categoria_book'];
    $editorial_book = $_POST['editorial_book'];
    $stock_book = $_POST['stock_book'];

    $nombreImagen = $_FILES['imagen']['name'];
    $archivo = $_FILES['imagen']['tmp_name'];
    $rutaImg = '../img/upload';
    $rutaImg = $rutaImg . "/" . $nombreImagen;

    move_uploaded_file($archivo, $rutaImg);

    $msgGeneral = "";
    $validacion = True;

    //Validamos los campos requeridos
    if (!$name_book) {
        $validacion = False;
    }
    if (!$categoria_book) {
        $validacion = False;
    }
    if ($validacion) {
        $sqlSelectBook = "SELECT * FROM `books` WHERE name_book = '$name_book' AND NOT id_books = '$codBook';";
        $psBook = $cnx->prepare($sqlSelectBook);
        $psBook->execute();
        $resBookInsert = $psBook->fetchAll();


        if (!$resBookInsert) {
            $sqlUpdate = "UPDATE `books` SET `id_cat` = ?, `name_book` = ?, `id_autor` = ?, `id_edit` = ?, `stock_book` = ?, `file_book` = ? WHERE `id_books` = ?;";
            $psUpdate = $cnx->prepare($sqlUpdate);
            $psUpdate->execute(array($categoria_book, $name_book, $autor_book, $editorial_book, $stock_book, $rutaImg, $codBook));
            if ($psUpdate->rowCount()) {
                //Si todo está correcto se modifican los datos
                $msgGeneral = "Modificacion correcta";
            } else {
                //Si ocurre algun error nos mostrará el mensaje de modificacion incorrecta
                $msgGeneral = "Modificacion incorrecta";
            }
        } else {
            $msgGeneral = 'Este libro ya existe';
        }
    } else {
        //Si faltan campos necesarios mostrará el mensaje
        $msgGeneral = 'Faltan campos necesarios';
    }
}

$sqlSelectCat = "SELECT * FROM `categorias`;";
$psCat = $cnx->prepare($sqlSelectCat);
$psCat->execute();
$resCategoria = $psCat->fetchAll();

$sqlSelectAut = "SELECT * FROM `autores`;";
$psAut = $cnx->prepare($sqlSelectAut);
$psAut->execute();
$resAutor = $psAut->fetchAll();

$sqlSelectEdit = "SELECT * FROM `editoriales`;";
$psEdit = $cnx->prepare($sqlSelectEdit);
$psEdit->execute();
$resEditorial = $psEdit->fetchAll();

//Seleccionamos los datos de la tabla según el codBook previamente recibido
$sqlInner = "SELECT * FROM books INNER JOIN editoriales ON books.id_edit = editoriales.id_edit INNER JOIN categorias ON books.id_cat = categorias.id_cat INNER JOIN autores ON books.id_autor = autores.id_autor WHERE books.id_books = $codBook;";
$psInner = $cnx->prepare($sqlInner);
$psInner->execute();
$resLibroMod = $psInner->fetchAll();

include("../inc/header.php");
?>


<!--Body Center, Aqui va el contenido-->
<div id="body-content" style="color: black;">

    <div id="body-center">
        <div id="body-header-static" style=" margin-left: 5rem; margin-top: 2rem; margin-bottom: 3rem;">
            <p>Modificar Libro</p>
        </div>

        <form action="modificar.php" method="POST" enctype="multipart/form-data" id="form-aña">
            <!-- Mostramos los datos recibidos según codBook -->
            <?php foreach ($resLibroMod as $libro) { ?>

                <div id="vista-previa-container" style="display: inline-flex;height: 30rem;">
                    <div id="input-añadir-libro">
                        <p>Nombre</p>
                        <input type="text" name="name_book" id="name_book" minlength="4" maxlength="30" value="<?php echo $libro['name_book'] ?>">
                        <p>Autor</p>
                        <select id="selectM" name="autor_book">
                            <option class="optionM" value="<?php echo $libro['id_autor'] ?>" selected><?php echo $libro['name_autor'] ?></option>
                            <?php foreach ($resAutor as $autor) { ?>
                                <!-- Mostramos las categorias de nuestra tabla categoria -->
                                <option class="optionM" value="<?php echo $autor['id_autor'] ?>"><?php echo $autor['name_autor'] ?></option>
                            <?php } ?>
                        </select>
                        <p>Editorial</p>
                        <select id="selectM" name="editorial_book">
                            <option class="optionM" value="<?php echo $libro['id_edit'] ?>" selected><?php echo $libro['name_edit'] ?></option>
                            <?php foreach ($resEditorial as $edit) { ?>
                                <!-- Mostramos las categorias de nuestra tabla categoria -->
                                <option class="optionM" value="<?php echo $edit['id_edit'] ?>"><?php echo $edit['name_edit'] ?></option>
                            <?php } ?>
                        </select>
                        <p>Categoria</p>
                        <select id="selectM" name="categoria_book">
                            <option class="optionM" value="<?php echo $libro['id_cat'] ?>" selected><?php echo $libro['name_cat'] ?></option>
                            <?php foreach ($resCategoria as $cat) { ?>
                                <!-- Mostramos las categorias de nuestra tabla categoria -->
                                <option class="optionM" value="<?php echo $cat['id_cat'] ?>"><?php echo $cat['name_cat'] ?></option>
                            <?php } ?>
                        </select>
                        <p>Stock</p>
                        <input type="number" name="stock_book" id="stock_book" value="<?php echo $libro['stock_book'] ?>">
                        <input type="hidden" name="codBook" id="codBook" value="<?php echo $libro['id_books'] ?>">
                        <input type="hidden" name="enviado" id="enviado" value="1">
                        <div id="btns-under-input-aña">
                            <a href="../home/index.php" style="color: #686767;"><button type="button" id="cancelar" style="border: #7c7c7c solid 2px; margin-right: 2rem; cursor:pointer;">CANCELAR</button></a>
                            <button id="aplicar">APLICAR</button>
                            <p style="margin-top:1rem;"><?php echo $msgGeneral; ?></p>
                        </div>
                    </div>
                    <div id="vista-previa">
                        <p style="margin-left: 1rem; margin-top: 1rem; position: absolute">VISTA PREVIA</p>
                        <img id="caratula" src="<?php echo $libro['file_book']; ?>">
                    </div>
                </div>
                <div id="btn-under-vista-previa" style="margin-left: 61rem; display: inline-flex;">
                    <p>Portada / Caratula</p>
                    <button type="button" id="btn-subir-aña">
                        <label for="file_button">SUBIR</label>
                        <input type="file" id="file_button" name="imagen" class="inputfile">
                    </button>
                </div>
        </form>
    <?php } ?>
    </div>
</div>

<!--Body Center end-->
<?php include("../inc/footer.php"); ?>
<style>
    .inputfile {
        width: 0.1px;
        height: 0.1px;
        opacity: 0;
        overflow: hidden;
        position: absolute;
        z-index: -1;
    }
</style>

<script>
    var input=  document.getElementById('stock_book');
        input.addEventListener('input',function(){
        if (this.value.length > 4) 
        this.value = this.value.slice(0,4); 
    })
</script>

<script>
    window.onload = function() {
        let productos = document.getElementById('Productos-navbar');
        let dash = document.getElementById('Dashboard-navbar');
        let categorias = document.getElementById('Categorias-navbar');
        let autores = document.getElementById('Auto-navbar');
      
        productos.style.color = '#a9a6a6';

        
    }
</script>